# coding: utf-8
# Copyright (c) 2023, Oracle and/or its affiliates.  All rights reserved.
# This software is dual-licensed to you under the Universal Permissive License (UPL) 1.0 as shown at https://oss.oracle.com/licenses/upl or Apache License 2.0 as shown at http://www.apache.org/licenses/LICENSE-2.0. You may choose either license.

from __future__ import annotations
from typing import Any, Dict, List, Optional
from abc import ABC

from langchain.llms.base import LLM
from langchain.callbacks.manager import CallbackManagerForLLMRun
from langchain.pydantic_v1 import BaseModel, Extra, root_validator
from langchain.llms.utils import enforce_stop_tokens

class OCIGenAIBase(BaseModel, ABC):
    """Base class for OCI GenAI models"""

    client: Any  #: :meta private:

    auth_type: Optional[str] = None
    """Authentication type, could be API_KEY or SECURITY_TOKEN
    If not specified, API_KEY will be used
    """

    auth_profile: Optional[str] = None
    """The name of the profile in ~/.oci/config
    If not specified , DEFAULT will be used. 
    """

    model_id: str = None
    """Id of the model to call, e.g., cohere.command"""

    model_kwargs: Optional[Dict] = None
    """Keyword arguments to pass to the model. placeholder for future model arguments"""

    service_endpoint: str = None
    """service endpoint url"""

    compartment_id: str = None
    """OCID of compartment"""

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        """Validate that OCI config and python package exists in environment."""

        # Skip creating new client if passed in constructor
        if values["client"] is not None:
            return values
         
        try:
            import oci

            def make_security_token_signer(oci_config):
                pk = oci.signer.load_private_key_from_file(oci_config.get("key_file"), None)
                with open(oci_config.get("security_token_file")) as f:
                    st_string = f.read()
                return oci.auth.signers.SecurityTokenSigner(st_string, pk)
            
            if values["auth_profile"] is not None:
                config = oci.config.from_file(profile_name=values["auth_profile"])
            else:
                config = oci.config.from_file()
                
            if values["auth_type"] is not None:
                signer = make_security_token_signer(oci_config=config)
                values["client"] = oci.generative_ai.GenerativeAiClient(config=config, service_endpoint=values["service_endpoint"], retry_strategy=oci.retry.DEFAULT_RETRY_STRATEGY, signer=signer, timeout=(10,240))
            else:
                values["client"] = oci.generative_ai.GenerativeAiClient(config=config, service_endpoint=values["service_endpoint"], retry_strategy=oci.retry.DEFAULT_RETRY_STRATEGY, timeout=(10,240))
                
            
        except ImportError:
            raise ModuleNotFoundError(
                "Could not import oci python package. "
                "Please make sure you have the oci package installed."
            )
        except Exception as e:
            raise ValueError(
                "Could not load config to authenticate with OCI client. "
                "Please check ~/.oci/config exists. And the specified "
                "profile name are valid."
            ) from e
        
        return values

class OCIGenAI(LLM, OCIGenAIBase):
    """OCI large language models.

    To authenticate, the OCI client uses the following methods to
    automatically load config:
    https://docs.oracle.com/en-us/iaas/Content/API/Concepts/sdkconfig.htm

    If a specific config profile should be used, you must pass
    the name of the profile from the ~/.oci/config file that is to be used.

    Make sure the profile / roles used have the required policies to
    access the OCI Generative AI service.
    
    To use, you should pass the compartment id 
    along with the endpoint url, 
    as named parameters to the constructor.
    
    Example:
        .. code-block:: python

            from langchain.llms import OCIGenAI

            llm = OCIGenAI(
                    model_id="cohere.command", 
                    service_endpoint=endpoint,
                    compartment_id=compartment_id
                )
    """
    #  TODO: - add async support (when supported by the Generative AI Service)
    #        - add streaming support (when supported by the Generative AI Service)
    #        - open source model support (when supported by the Generative AI Service)
    
    temperature: float = 0.7
    """A non-negative float that tunes the degree of randomness in generation."""
    
    max_tokens: int = 256
    """Denotes the number of tokens to predict per generation."""

    top_k: int = 0
    """Number of most likely tokens to consider at each step."""

    top_p: int = 1
    """Total probability mass of tokens to consider at each step."""

    frequency_penalty: float = 0.0
    """Penalizes repeated tokens according to frequency. Between 0 and 1."""

    presence_penalty: float = 0.0
    """Penalizes repeated tokens. Between 0 and 1."""

    truncate: str = "END"
    """Specify how the client handles inputs longer than the maximum token
       length: Truncate from START, END or NONE"""

    stop: Optional[List[str]] = None
    """The generated text will be cut at the end of the earliest occurence of a stop sequence. The sequence will be included the text.
       For LangChain consistency, the included stop sequence will be removed (handled by LangChain)"""
    
    class Config:
        """Configuration for this pydantic object."""
        extra = Extra.forbid

    @property
    def _llm_type(self) -> str:
        """Return type of llm."""
        return "oci"
    
    @property
    def _default_params(self) -> Dict[str, Any]:
        """Get the default parameters."""
        return {
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "top_k": self.top_k,
            "top_p": self.top_p,
            "frequency_penalty": self.frequency_penalty,
            "presence_penalty": self.presence_penalty,
            "truncate": self.truncate,
        }
    
    @property
    def _identifying_params(self) -> Dict[str, Any]:
        """Get the identifying parameters."""
        return {**{"model_id": self.model_id}, **self._default_params}
    
    def _prepare_invocation_object(self, prompt: str, stop: Optional[List[str]], kwargs: Dict[str, Any]) -> Dict[str, Any]:

        params = self._default_params

        if self.stop is not None and stop is not None:
            raise ValueError("'stop' found in both the input and default params.")
        elif self.stop is not None:
            params["stop_sequences"] = self.stop
        else:
            params["stop_sequences"] = stop

        # override default params with those in kwargs
        for k, v in kwargs.items():
            if k in params:
                params[k] = v
            else:
                raise ValueError(f"Invalid argument '{k}'")
        import oci
        invocation_obj = oci.generative_ai.models.GenerateTextDetails(**params)
        invocation_obj.compartment_id = self.compartment_id
        invocation_obj.serving_mode = oci.generative_ai.models.OnDemandServingMode(model_id=self.model_id)
        invocation_obj.prompts = [prompt]
       
        return invocation_obj
    
    def _process_response(self, response: Any, stop: Optional[List[str]]) -> str:
        text = response.data._generated_texts[0][0].text
        # If stop tokens are provided, the service returns them.
        # In order to make this consistent with LangChain, we strip them.
        if stop:
            text = enforce_stop_tokens(text, stop)
        return text
    
    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """Call out to OCIGenAI generate endpoint.

        Args:
            prompt: The prompt to pass into the model.
            stop: Optional list of stop words to use when generating.

        Returns:
            The string generated by the model.

        Example:
            .. code-block:: python

               response = OCIGenAI("Tell me a joke.")
        """
                
        invocation_obj = self._prepare_invocation_object(prompt, stop, kwargs)
        response = self.client.generate_text(invocation_obj)
        _stop = invocation_obj.stop_sequences
        return self._process_response(response, _stop)
    

    