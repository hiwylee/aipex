# coding: utf-8
# Copyright (c) 2023, Oracle and/or its affiliates.  All rights reserved.
# This software is dual-licensed to you under the Universal Permissive License (UPL) 1.0 as shown at https://oss.oracle.com/licenses/upl or Apache License 2.0 as shown at http://www.apache.org/licenses/LICENSE-2.0. You may choose either license.

from typing import Any, Dict, List, Optional
from langchain.pydantic_v1 import BaseModel, Extra, root_validator
from langchain.schema.embeddings import Embeddings
from langchain.utils import get_from_dict_or_env

class OCIGenAIEmbeddings(BaseModel, Embeddings):
    """OCI embedding models.

    To authenticate, the OCI client uses the following methods to
    automatically load config:
    https://docs.oracle.com/en-us/iaas/Content/API/Concepts/sdkconfig.htm

    If a specific config profile should be used, you must pass
    the name of the profile from the ~/.oci/config file that is to be used.

    Make sure the profile / roles used have the required policies to
    access the OCI Generative AI service.
    
    To use, you should pass the compartment id 
    along with the endpoint url, 
    as named parameters to the constructor.

    Example:
        .. code-block:: python

            from langchain.embeddings import OCIGenAIEmbeddings

            embeddings = OCIGenAIEmbeddings(
                    model_id="cohere.embed-english-light-v2.0", 
                    service_endpoint=endpoint,
                    compartment_id=compartment_id
                )
    """
    #  TODO: - add async support (when supported by the Generative AI Service)
    
    client: Any  #: :meta private:

    auth_type: Optional[str] = None
    """Authentication type, could be API_KEY or SECURITY_TOKEN
    If not specified, API_KEY will be used
    """

    auth_profile: Optional[str] = None
    """The name of the profile in ~/.oci/config
    If not specified , DEFAULT will be used. 
    """

    service_endpoint: str = None
    """service endpoint url"""

    compartment_id: str = None
    """OCID of compartment"""

    model_id: str = None
    """Id of the model to call, e.g., cohere.embed-english-light-v2.0"""
    
    truncate: Optional[str] = "END"
    """Truncate embeddings that are too long from start or end ("NONE"|"START"|"END")"""

    class Config:
        """Configuration for this pydantic object."""
        extra = Extra.forbid

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        """Validate that OCI config and python package exists in environment."""

        # Skip creating new client if passed in constructor
        if values["client"] is not None:
            return values
         
        try:
            import oci

            def make_security_token_signer(oci_config):
                pk = oci.signer.load_private_key_from_file(oci_config.get("key_file"), None)
                with open(oci_config.get("security_token_file")) as f:
                    st_string = f.read()
                return oci.auth.signers.SecurityTokenSigner(st_string, pk)
            
            if values["auth_profile"] is not None:
                config = oci.config.from_file(profile_name=values["auth_profile"])
            else:
                config = oci.config.from_file()
                
            if values["auth_type"] is not None:
                signer = make_security_token_signer(oci_config=config)
                values["client"] = oci.generative_ai.GenerativeAiClient(config=config, service_endpoint=values["service_endpoint"], retry_strategy=oci.retry.DEFAULT_RETRY_STRATEGY, signer=signer, timeout=(10,240))
            else:
                values["client"] = oci.generative_ai.GenerativeAiClient(config=config, service_endpoint=values["service_endpoint"], retry_strategy=oci.retry.DEFAULT_RETRY_STRATEGY, timeout=(10,240))
                
            
        except ImportError:
            raise ModuleNotFoundError(
                "Could not import oci python package. "
                "Please make sure you have the oci package installed."
            )
        except Exception as e:
            raise ValueError(
                "Could not load config to authenticate with OCI client. "
                "Please check ~/.oci/config exists. And the specified "
                "profile name are valid."
            ) from e
        
        return values

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Call out to OCIGenAI's embedding endpoint.

        Args:
            texts: The list of texts to embed.

        Returns:
            List of embeddings, one for each text.
        """
        import oci
        invocation_obj = oci.generative_ai.models.EmbedTextDetails()
        invocation_obj.serving_mode = oci.generative_ai.models.OnDemandServingMode(model_id=self.model_id)
        invocation_obj.compartment_id = self.compartment_id
        invocation_obj.truncate = self.truncate
        invocation_obj.inputs = texts
        
        response = self.client.embed_text(invocation_obj)
              
        return response.data.embeddings

    def embed_query(self, text: str) -> List[float]:
        """Call out to OCIGenAI's embedding endpoint.

        Args:
            text: The text to embed.

        Returns:
            Embeddings for the text.
        """
        return self.embed_documents([text])[0]